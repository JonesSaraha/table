﻿using WebApplication5.Models;
using Newtonsoft.Json;  // Only one import needed here
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace WebApplication5.Services
{
    public class StudentService
    {
        private readonly string _jsonPath;

        public StudentService(IWebHostEnvironment env)
        {
            _jsonPath = Path.Combine(env.ContentRootPath, "wwwroot", "studentdata.json");
        }

        public List<Student> GetAllStudents()
        {
            var json = File.ReadAllText(_jsonPath);
            return JsonConvert.DeserializeObject<List<Student>>(json) ?? new List<Student>();
        }

        public void SaveStudents(List<Student> students)
        {
            var json = JsonConvert.SerializeObject(students, Formatting.Indented);
            File.WriteAllText(_jsonPath, json);
        }

        public void DeleteStudent(int id)
        {
            var students = GetAllStudents();
            var studentToDelete = students.FirstOrDefault(s => s.Id == id);
            if (studentToDelete != null)
            {
                students.Remove(studentToDelete);
                SaveStudents(students);
            }
        }

        public void UpdateStudent(Student updatedStudent)
        {
            var students = GetAllStudents();
            var studentToUpdate = students.FirstOrDefault(s => s.Id == updatedStudent.Id);

            if (studentToUpdate != null)
            {
                studentToUpdate.Name = updatedStudent.Name;
                studentToUpdate.Grade = updatedStudent.Grade;
                studentToUpdate.Class = updatedStudent.Class;
                studentToUpdate.School = updatedStudent.School;
                SaveStudents(students);
            }
        }
    }
}


