﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebApplication5.Models;
using WebApplication5.Services;

namespace WebApplication5.Pages
{
    public class IndexModel : PageModel
    {
        private readonly StudentService _studentService;
        private const int PageSize = 5;

        public List<Student> Students { get; set; } = new();
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }

        [BindProperty(SupportsGet = true)]
        public string GlobalSearch { get; set; }

        [BindProperty(SupportsGet = true)]
        public string FieldSearch { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SearchField { get; set; }

        public IndexModel(StudentService studentService)
        {
            _studentService = studentService;
        }

        public void OnGet(int pageNumber = 1)
        {
            var allStudents = _studentService.GetAllStudents();

            if (!string.IsNullOrWhiteSpace(GlobalSearch))
            {
                var term = GlobalSearch.ToLower();
                allStudents = allStudents.Where(s =>
                    s.Name.ToLower().Contains(term) ||
                    s.Grade.ToLower().Contains(term) ||
                    s.Class.ToLower().Contains(term) ||
                    s.School.ToLower().Contains(term)).ToList();
            }

            if (!string.IsNullOrWhiteSpace(SearchField) && !string.IsNullOrWhiteSpace(FieldSearch))
            {
                var value = FieldSearch.ToLower();
                allStudents = SearchField switch
                {
                    "Name" => allStudents.Where(s => s.Name.ToLower().Contains(value)).ToList(),
                    "Grade" => allStudents.Where(s => s.Grade.ToLower().Contains(value)).ToList(),
                    "Class" => allStudents.Where(s => s.Class.ToLower().Contains(value)).ToList(),
                    "School" => allStudents.Where(s => s.School.ToLower().Contains(value)).ToList(),
                    _ => allStudents
                };
            }

            TotalPages = (int)Math.Ceiling(allStudents.Count / (double)PageSize);
            Students = allStudents.Skip((pageNumber - 1) * PageSize).Take(PageSize).ToList();
            CurrentPage = pageNumber;
        }

        public IActionResult OnPostDelete(int id)
        {
            _studentService.DeleteStudent(id);
            return RedirectToPage();
        }

        public IActionResult OnPostEdit(Student student)
        {
            _studentService.UpdateStudent(student);
            return RedirectToPage();
        }
    }
}



